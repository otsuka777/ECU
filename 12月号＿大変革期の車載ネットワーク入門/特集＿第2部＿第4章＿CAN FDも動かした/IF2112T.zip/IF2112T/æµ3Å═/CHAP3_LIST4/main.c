#include "rscan_def.h"

int main(void)
{
	volatile int err;
	int	ID;
	int	CTR;
	int	DAT0;
	int	DAT1;
	
	while((RSCANnGSTS & (1<<3))!=0);

	RSCANnGCTR &= (0xffffffff ^ (1<<2));
	while((RSCANnGCTR & (1<<2))!=0);

	RSCANnC0CTR &= (0xffffffff ^ (1<<2));
	RSCANnC1CTR &= (0xffffffff ^ (1<<2));
	
	while((RSCANnC0CTR & (1<<2))!=0);
	while((RSCANnC1CTR & (1<<2))!=0); 
	
	RSCANnC0FDCFG = (1<<30);
	RSCANnC1FDCFG = (1<<30);

	RSCANnGCFG = (1<<4);

	RSCANnC0NCFG = (0<11)|(12<<16)|(5<<24);
	RSCANnC1NCFG = (0<11)|(12<<16)|(5<<24);
	RSCANnC0DCFG = (0<11)|(12<<16)|(5<<24);
	RSCANnC1DCFG = (0<11)|(12<<16)|(5<<24);

	RSCANnGAFLECTR = (RSCANnGAFLECTR & 0xffffffe0)|0x100;

	RSCANnRMNB = 2;
	RSCANnGAFLCFG0 = (0x1<<24)|(0x1<<16);

	RSCANnGAFLID0 = (0<<31)|(1<<30)|(0<<29)|0x123;
	RSCANnGAFLM0  = (0<<31)|(0<<30)|0xfffffff;
	RSCANnGAFLP00 = (0xaaa<<16)|(1<<15)|(0<<8)|8;
	RSCANnGAFLP10 = 0;
	
	RSCANnGAFLID1 = (0<<31)|(1<<30)|(0<<29)|0x123;
	RSCANnGAFLM1  = (0<<31)|(0<<30)|0xfffffff;
	RSCANnGAFLP01 = (0xaaa<<16)|(1<<15)|(0<<8)|8;
	RSCANnGAFLP11 = 0;
	

	RSCANnRFCC0 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC1 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC2 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC3 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC4 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC5 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC6 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);
	RSCANnRFCC7 = (7<<13)|(1<<12)|(2<<8)|(1<<1)|(1<<0);

	RSCANnGCTR &= 0xfffffffc;
	while((RSCANnGCTR & 0x3)!=0);

	RSCANnC0CTR &= 0xfffffffc;
	while((RSCANnC0CTR & 0x3)!=0);
	
	RSCANnC1CTR &= 0xfffffffc;
	while((RSCANnC0CTR & 0x3)!=0);
again:
	{ volatile int i;
		for(i=0;i<100;i++);
	}

	RSCANnTMID0 = (0<<31)|(1<<30)|(0<<29)|0x123;
	RSCANnTMPTR0 = (8<<28);
	RSCANnTMDF00 = (0x78<<24)|(0x56<<16)|(0x34<<8)|(0x12);
	RSCANnTMDF10 = (0xf0<<24)|(0xde<<16)|(0xbc<<8)|(0x9a);

	RSCANnTMC0 |= 0x1;

	while(RSCANnTMSTS0 != 0x4);
	RSCANnTMSTS0 =0;
	goto again;
	 
	
	while(RSCANnRMND0 == 0);

	ID = RSCANnRMID0;
	CTR = RSCANnRMPTR0;
	DAT0 = RSCANnRMDF00;
	DAT1 = RSCANnRMDF10;
	
	err = 0;	
	if(ID != 0x40000123) err++;
	CTR = (CTR >> 28)&0xf;
	if(CTR != 0x8) err++;
//	if(DAT0 != 0x78563412) err++;
//	if(DAT1 != 0xf0debc9a) err++;
	
	return err;
}
