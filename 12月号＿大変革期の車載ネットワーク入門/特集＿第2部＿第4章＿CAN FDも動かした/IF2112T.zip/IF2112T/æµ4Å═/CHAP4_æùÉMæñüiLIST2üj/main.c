#include "rscan_def.h"

int main(void)
{
	volatile int err;
	int	ID;
	int	CTR;
	int	DAT[16];

	while((RSCANnGSTS & (1<<3))!=0);

	RSCANnGCTR &= (0xffffffff ^ (1<<2));
	while((RSCANnGCTR & (1<<2))!=0);

	RSCANnC0CTR &= (0xffffffff ^ (1<<2));
	RSCANnC1CTR &= (0xffffffff ^ (1<<2));
	
	while((RSCANnC0CTR & (1<<2))!=0);
	while((RSCANnC1CTR & (1<<2))!=0); 
	
	RSCANnC0FDCFG = (0<<30)|(1<<28)|(1<<10); // set CAN-FD mode CLOE, FDOE
	RSCANnC1FDCFG = (0<<30)|(1<<28)|(1<<10); // set CAN-FD mode

	RSCANnGCFG = (0<<4);//

//	RSCANnC0NCFG = (0<11)|(12<<16)|(5<<24);
//	RSCANnC1NCFG = (0<11)|(12<<16)|(5<<24);
	RSCANnC0NCFG = (3<<11)|(38<<16)|(9<<24);
	RSCANnC1NCFG = (3<<11)|(38<<16)|(9<<24);
//	RSCANnC0DCFG = (5<16)|(1<<20)|(0<<24);//
//	RSCANnC1DCFG = (5<16)|(1<<20)|(0<<24);//
	RSCANnC0DCFG = (6<<16)|(1<<20)|(0<<24);//
	RSCANnC1DCFG = (6<<16)|(1<<20)|(0<<24);//

	RSCANnGAFLECTR = (RSCANnGAFLECTR & 0xffffffe0)|0x100;

	RSCANnRMNB = (7<<8)|2;//
	RSCANnGAFLCFG0 = (0x1<<24)|(0x1<<16);

	RSCANnGAFLID0 = (0<<31)|(0<<30)|(0<<29)|0x123;
	RSCANnGAFLM0  = (0<<31)|(0<<30)|0xfffffff;
	RSCANnGAFLP00 = (0xaaa<<16)|(1<<15)|(0<<8)|15;//
	RSCANnGAFLP10 = 0;
	
	RSCANnGAFLID1 = (0<<31)|(0<<30)|(0<<29)|0x123;
	RSCANnGAFLM1  = (0<<31)|(0<<30)|0xfffffff;
	RSCANnGAFLP01 = (0xaaa<<16)|(1<<15)|(0<<8)|15;//
	RSCANnGAFLP11 = 0;
	

	RSCANnRFCC0 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC1 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC2 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC3 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC4 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC5 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC6 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);
	RSCANnRFCC7 = (7<<13)|(1<<12)|(6<<8)|(1<<1)|(1<<0);

	RSCANnGCTR &= 0xfffffffc;
	while((RSCANnGCTR & 0x3)!=0);

	RSCANnC0CTR &= 0xfffffffc;
	while((RSCANnC0CTR & 0x3)!=0);
	
	RSCANnC1CTR &= 0xfffffffc;
	while((RSCANnC0CTR & 0x3)!=0);
again:
	{ volatile int i;
		for(i=0;i<100;i++);
	}

	RSCANnTMID0 = (0<<31)|(0<<30)|(0<<29)|0x123;
	RSCANnTMPTR0 = (15<<28);
	RSCANnTMFDCTR0 = (0xaaa<<16)|(1<<2)|(1<<1)|1;//
	RSCANnTMDF00 = (0x04<<24)|(0x03<<16)|(0x02<<8)|(0x01);
	RSCANnTMDF10 = (0x08<<24)|(0x07<<16)|(0x06<<8)|(0x05);
	RSCANnTMDF20 = (0x0c<<24)|(0x0b<<16)|(0x0a<<8)|(0x09);
	RSCANnTMDF30 = (0x10<<24)|(0x0f<<16)|(0x0e<<8)|(0x0d);
	RSCANnTMDF40 = (0x14<<24)|(0x13<<16)|(0x12<<8)|(0x11);
	RSCANnTMDF50 = (0x18<<24)|(0x17<<16)|(0x16<<8)|(0x15);
	RSCANnTMDF60 = (0x1c<<24)|(0x1b<<16)|(0x1a<<8)|(0x19);
	RSCANnTMDF70 = (0x20<<24)|(0x1f<<16)|(0x1e<<8)|(0x1d);
	RSCANnTMDF80 = (0x24<<24)|(0x23<<16)|(0x22<<8)|(0x21);
	RSCANnTMDF90 = (0x28<<24)|(0x27<<16)|(0x26<<8)|(0x25);
	RSCANnTMDF100 = (0x2c<<24)|(0x2b<<16)|(0x2a<<8)|(0x29);
	RSCANnTMDF110 = (0x30<<24)|(0x2f<<16)|(0x2e<<8)|(0x2d);
	RSCANnTMDF120 = (0x34<<24)|(0x33<<16)|(0x32<<8)|(0x31);
	RSCANnTMDF130 = (0x38<<24)|(0x37<<16)|(0x36<<8)|(0x35);
	RSCANnTMDF140 = (0x3c<<24)|(0x3b<<16)|(0x3a<<8)|(0x39);
	RSCANnTMDF150 = (0x40<<24)|(0x3f<<16)|(0x3e<<8)|(0x3d);

	RSCANnTMC0 |= 0x1;

	while(RSCANnTMSTS0 != 0x4);
	RSCANnTMSTS0 =0;
	goto again;

	while(RSCANnRMND0 ==0);

	ID = RSCANnRMID0;
	CTR = RSCANnRMPTR0;
	DAT[0] = RSCANnRMDF00;
	DAT[1] = RSCANnRMDF10;
	DAT[2] = RSCANnRMDF20;
	DAT[3] = RSCANnRMDF30;
	DAT[4] = RSCANnRMDF40;
	DAT[5] = RSCANnRMDF50;
	DAT[6] = RSCANnRMDF60;
	DAT[7] = RSCANnRMDF70;
	DAT[8] = RSCANnRMDF80;
	DAT[9] = RSCANnRMDF90;
	DAT[10] = RSCANnRMDF100;
	DAT[11] = RSCANnRMDF110;
	DAT[12] = RSCANnRMDF120;
	DAT[13] = RSCANnRMDF130;
	DAT[14] = RSCANnRMDF140;
	DAT[15] = RSCANnRMDF150;
	
	err = 0;	
	if(ID != 0x123) err++;
	CTR = (CTR >> 28)&0xf;
	if(CTR != 0xf) err++;
	if(DAT[0] != 0x04030201) err++;
	if(DAT[1] != 0x08070605) err++;
	if(DAT[2] != 0x0c0b0a09) err++;
	if(DAT[3] != 0x100f0e0d) err++;
	if(DAT[4] != 0x14131211) err++;
	if(DAT[5] != 0x18171615) err++;
	if(DAT[6] != 0x1c1b1a19) err++;
	if(DAT[7] != 0x201f1e1d) err++;
	if(DAT[8] != 0x24232221) err++;
	if(DAT[9] != 0x28272625) err++;
	if(DAT[10] != 0x2c2b2a29) err++;
	if(DAT[11] != 0x302f2e2d) err++;
	if(DAT[12] != 0x34333231) err++;
	if(DAT[13] != 0x38373635) err++;
	if(DAT[14] != 0x3c3b3a39) err++;
	if(DAT[15] != 0x403f3e3d) err++;
	
	return err;
}
